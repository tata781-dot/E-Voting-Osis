# E-Voting OSIS — GitHub Pages

## File yang di-upload
Upload **isi folder ini** ke repository GitHub yang mengaktifkan GitHub Pages:
- `index.html` — aplikasi utama (nama file wajib `index.html` agar root website terbuka).
- `.nojekyll` — mencegah pemrosesan Jekyll pada file statis.

## Cara upload
1. Buka repository GitHub untuk website E-Voting OSIS.
2. Pilih **Add file → Upload files**.
3. Upload `index.html` dan `.nojekyll` dari folder ini (bukan file ZIP).
4. Jika ada file `index.html` lama, pilih untuk menggantinya.
5. Buka **Settings → Pages**. Pilih branch yang dipakai (umumnya `main`) dan folder `/ (root)`, lalu **Save**.
6. Tunggu proses deploy selesai. Buka alamat GitHub Pages dengan HTTPS.

## Buka di smartphone
- Android: buka tautan GitHub Pages di Chrome.
- iPhone/iPad: buka di Safari.
- Jika halaman lama masih muncul, refresh atau hapus cache situs lalu buka lagi.
- Gunakan koneksi internet karena aplikasi memuat Tailwind, Chart.js, ikon, dan pustaka impor dari CDN.

## Catatan penting sebelum pemungutan suara sungguhan
Versi ini adalah situs statis GitHub Pages. Data aplikasi menggunakan `localStorage` di browser/perangkat masing-masing. Artinya, data suara, token, perubahan admin, dan hasil **tidak otomatis tersinkron antar-HP/laptop**. Pengguna juga dapat menghapus data browser. Password admin yang ditanam di JavaScript bukan autentikasi server yang aman. Jadi versi ini cocok untuk demo/uji tampilan; untuk pemilu resmi lintas perangkat, perlu backend/database dengan autentikasi dan aturan keamanan di server.
